<?php

namespace App\Http\Controllers\UserController;
use Illuminate\Http\Request;

class UserController extends Controller
{
	public function user_registration(){
		$data = 'hello';
		return $data;

	}
}
